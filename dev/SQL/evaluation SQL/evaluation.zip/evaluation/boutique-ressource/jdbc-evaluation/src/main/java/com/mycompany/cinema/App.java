package com.mycompany.cinema;

/**
 * Exemple avec le model Entity / Repository.
 */
public class App 
{ 
    /**
     * Point d'entrée du programme en java.
     * 
     * @param args
     */
    public static void main( String[] args )
    {
        //code voir énoncé de l'évaluation
    }
}

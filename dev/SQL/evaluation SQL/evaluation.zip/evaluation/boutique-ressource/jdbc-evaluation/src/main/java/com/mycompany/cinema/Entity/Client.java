package com.mycompany.cinema.Entity;

public class Client {

    public Client() {
        
    }
}
package demo;

import entity.Animal;
import entity.Chat;
import entity.PoissonRouge;

public class Execution {

	public static void main(String[] args) {
		
		Chat loulou = new Chat();
		loulou.setNom("Loulou");
		loulou.setCouleurCollier("Rouge");
		
		//loulou.crier();
		
		PoissonRouge nemo = new PoissonRouge();
		nemo.setNom("nemo");
		nemo.setSurfaceBocal(100);
		
		Animal a1 = loulou;
		Animal a2 = nemo;
		 
		a1.crier();
		a2.crier();
		
		/*
		Animal[] tabAnimal = new Animal[2];
		tabAnimal[0] = loulou;
		tabAnimal[1] = nemo;
		
		for(Animal animal : tabAnimal) {
			//animal.presentation();
			//animal.manger("pain");
			animal.crier();
		}
		*/
		
		
	}
}
